Development takes place on the `master` branch.  Please run `grunt` to rebuild the dist and run tests.

